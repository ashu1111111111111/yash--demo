import React from 'react'

function Monitor() {
  return (
    <div>
    <div>Monitor</div>
    <h1>as</h1>
    <h1>as</h1>
    <h1>as</h1>
    <h1>as</h1>
    <h1>as</h1>
    <h1>as</h1>
    <h1>as</h1>
    </div>
  )
}

export default Monitor